#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

#include "pico/stdlib.h"
#include "hardware/i2c.h"
#include "pico/util/queue.h"

#include "utils/sm.h"

#define CLK_DIV 125 // PWM clock divider
#define TOP 999 // PWM counter top value

#define SW_R 7 // right button - decreases brightness
#define SW_M 8 // middle button - light switch
#define SW_L 9 // left button - increases brightness
#define BUTTONS_SIZE 3 // how many buttons
static const uint buttons[] = {SW_R, SW_M, SW_L};

#define DEBOUNCE_MS 20 // Debounce delay in milliseconds

#define BAUD_RATE_I2C 100000 // I2C clock speed for EEPROM communication

#define I2C i2c0
// I2C pins
#define I2C_SDA 16 // Serial Data Line
#define I2C_SCL 17 // Serial Clock Line
#define I2C_SIZE 2

#define EEPROM_ADDRESS 0x50 // EEPROM I2C address
static const uint i2cs[] = {I2C_SDA, I2C_SCL};

#define INPUT_LEN 32

// Type of event coming from the interrupt callback
typedef enum { EV_SW_M, EV_SW_L, EV_SW_R, EV_PIEZO } event_type;

// Generic event passed from ISR to main loop through a queue
typedef struct {
    event_type type; // EVENT_BUTTON
    int32_t data; // BUTTON: 1 = press, 0 = release;
} event_t;

// Global event queue used by ISR (Interrupt Service Routine) and main loop
extern queue_t events;

void gpio_callback(uint gpio, uint32_t event_mask);
void init_buttons(); // Initialize buttons
void init_starting_state();

#endif