
#include <vector>
#include <string>

std::vector<std::string> data_locs = {
    "./","C:/Users/ville/Documents/GitHub/rpi-pico-minimal/cmake-build-debug/_deps/picotool/"
};
