#pragma once
#include <vector>
#include <string>

extern std::vector<std::string> data_locs;
