
#include <string>

const std::string rp2350_json = R"""(
@FILE_CONTENT@
)""";
