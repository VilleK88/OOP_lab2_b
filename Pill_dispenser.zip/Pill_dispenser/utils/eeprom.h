#ifndef LOG_H
#define LOG_H

#include "hardware/i2c.h"
#include "../main.h"

/*
 * EEPROM log entry configuration.
 *
 * LOG_ENTRY_SIZE:
 *   Total bytes reserved per log entry block.
 *
 * LOG_MAX_LEN:
 *   Maximum number of characters in log message (excluding CRC fields).
 *
 * MAX_LOGS:
 *   Number of log entries available in EEPROM (circular usage).
 */

#define LOG_ENTRY_SIZE 64
#define LOG_MAX_LEN 61
#define MAX_LOGS 32

#define WB_SLEEP_MS 5 // Delay after each EEPROM write (datasheet requirement)

/*
 * EEPROM memory map (top of memory downward).
 * All addresses are 16-bit and reserved for validated state storage.
 *
 * Layout (each entry takes 2 bytes unless otherwise noted):
 *
 *   32766  LED_L state
 *   32764  LED_M state
 *   32762  LED_R state
 *   32760  Stepper motor ON/OFF flag
 *   32758  Motor turn counter
 *   32756  Calibration status
 *   32752  Steps per revolution (16-bit value -> 4 bytes total)
 *   32750  State machine state (current application state)
 *   32748  Last pill dropped flag
 *   32746  Pills count
 */

#define LED_L_ADDR 32766
#define LED_M_ADDR 32764
#define LED_R_ADDR 32762
static const uint leds_addr[] = {LED_L_ADDR, LED_M_ADDR, LED_R_ADDR};

#define STEP_MOTOR_ADDR 32760
#define MOTOR_COUNT_ADDR 32758
#define CALIB_STATUS_ADDR 32756
#define STEPS_PER_REV_ADDR 32752

#define STATE_ADDR 32750 // Current state machine state

#define PILL_DROPPED_ADDR 32748
#define PILLS_COUNT_ADDR 32746


/*
 * Generic validated storage structures.
 * A valid entry must satisfy:
 *   not_state == ~state
 * Used to detect corruption after power loss or partial write.
 */

typedef struct gen_st {
    uint8_t state;
    uint8_t not_state;
} gen_st;

typedef struct gen_st16 {
    uint16_t state;
    uint16_t not_state;
} gen_st16;

void write_state(uint16_t addr, uint8_t state);
void set_state(gen_st *gst, uint8_t state);
void set_state16(gen_st16 *gst, uint16_t state);
void write_state_bytes(uint16_t addr, uint8_t state, uint8_t not_state);
void write_state16(uint16_t addr, uint16_t state);
void read_state16(uint16_t addr, uint16_t *state, uint16_t *not_state);
void read_state(uint16_t addr, uint8_t *state, uint8_t *not_state);
bool validate_state(uint16_t addr);
bool state_is_valid(const gen_st *gst);
bool validate_state16(uint16_t addr);
bool state16_is_valid(const gen_st16 *gst);
void write_log_entry(char *log);
void write_log_bytes(uint16_t address, const uint8_t *data, int total_log_len);
uint16_t next_log_index();
bool validate_log_entry(uint16_t addr);
void print_log_entries();
void read_log_entry(uint16_t addr, uint8_t *buffer);
void erase_log_entries();
uint16_t crc16(const uint8_t *data_p, size_t length);
void init_memory();
void write_byte(uint16_t address, uint8_t value);
uint8_t read_byte(uint16_t address);

#endif