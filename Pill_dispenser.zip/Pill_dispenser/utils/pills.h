#ifndef PILLS_H
#define PILLS_H

#include "stdint.h"
#include "../main.h"

/*
 * Boolean-style markers for pill detection.
 */
#define PILL_TRUE 1
#define PILL_FALSE 0

/*
 * Maximum number of pills the dispenser can hold.
 */
#define MAX_PILLS 7

/*
 * Redundant pill counter stored in EEPROM as
 * (value, bitwise-not-of-value) for integrity checking.
 */
typedef struct pills_state {
    uint8_t state;
    uint8_t not_state;
} pills_state;

/*
 * Combined pill-related state if needed for local state machines:
 * - pills_count: remaining pills in container
 * - pill_dropped: flag for last dispensing event
 */
typedef struct pills_sm {
    uint8_t pills_count;
    uint8_t pill_dropped;
} pills_sm;

void process_pill_dispense(bool pill);
void fill_the_pills(int pills_count);
void set_pills_state(pills_state *ps, uint8_t value);
int read_pills_count();
void init_pill_count_st();
void write_pills_count(int pills_count);
void write_pill_dropped_st(bool dropped);
bool read_if_pill_dropped();
bool pills_state_is_valid(const pills_state *ps);
void add_pill_log_entry(int pills_left, bool pill_dis);

#endif