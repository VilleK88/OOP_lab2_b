// EEPROM Memory and Log Storage
// Provides:
// - validated 8-bit and 16-bit state storage (value + ~value redundancy)
// - generic byte/word reading and writing
// - log storage with CRC validation
// - helper utilities for persistent subsystem initialization
#include "eeprom.h"
#include "lora.h"
#include "lights.h"
#include "pills.h"

/*
 * Store a single validated 8-bit value to EEPROM.
 * Writes (state, ~state) to the given address to allow integrity checking.
 */
void write_state(const uint16_t addr, const uint8_t state) {
    gen_st gst;
    set_state(&gst, state);
    write_state_bytes(addr, gst.state, gst.not_state);
}

/*
 * Construct a validated state pair for 8-bit values.
 */
void set_state(gen_st *gst, const uint8_t state) {
    gst->state = state;
    gst->not_state = ~state;
}

/*
 * Construct a validated state pair for 16-bit values.
 */
void set_state16(gen_st16 *gst, const uint16_t state) {
    gst->state = state;
    gst->not_state = ~state;
}

/*
 * Write two 8-bit values (state, not_state) to EEPROM at the given address.
 * Total write size: 2-byte address + 2 bytes of data.
 */
void write_state_bytes(const uint16_t addr, const uint8_t state, const uint8_t not_state) {
    const uint8_t buffer[4] = {
        addr >> 8 & 0xFF, addr & 0xFF,
        state, not_state,
    };
    // Send address, state and not_state
    i2c_write_blocking(I2C, EEPROM_ADDRESS, buffer, 4, false);
    sleep_ms(WB_SLEEP_MS);
}

/*
 * Write a validated 16-bit value as (state, ~state).
 * Total write size: 2-byte address + 4 bytes of data.
 */
void write_state16(const uint16_t addr, const uint16_t state) {
    gen_st16 gst;
    set_state16(&gst, state);
    const uint8_t buffer[6] = {
        addr >> 8 & 0xFF, addr & 0xFF,
        gst.state >> 8 & 0xFF, gst.state & 0xFF,
        gst.not_state >> 8 & 0xFF, gst.not_state & 0xFF
    };
    i2c_write_blocking(I2C, EEPROM_ADDRESS, buffer, sizeof(buffer), false);
    sleep_ms(WB_SLEEP_MS);
}

/*
 * Read a 16-bit validated state pair from EEPROM.
 * Reads 4 data bytes after writing 2-byte address.
 */
void read_state16(const uint16_t addr, uint16_t *state, uint16_t *not_state) {
    const uint8_t addr_part[2] = { addr >> 8 & 0xFF, addr & 0xFF };
    uint8_t data[4];
    i2c_write_blocking(I2C, EEPROM_ADDRESS, addr_part, sizeof(addr_part), true);
    i2c_read_blocking(I2C, EEPROM_ADDRESS, data, sizeof(data), false);
    *state = data[0] << 8 | data[1];
    *not_state = data[2] << 8 | data[3];
}

/*
 * Read an 8-bit validated state pair from EEPROM.
 */
void read_state(const uint16_t addr, uint8_t *state, uint8_t *not_state) {
    uint8_t buffer[2];
    buffer[0] = addr >> 8 & 0xFF; // MSB
    buffer[1] = addr & 0xFF; // LSB
    i2c_write_blocking(I2C, EEPROM_ADDRESS, buffer, 2,true);
    uint8_t data[2];
    i2c_read_blocking(I2C, EEPROM_ADDRESS, data, 2, false);
    *state = data[0];
    *not_state = data[1];
}

/*
 * Validate 8-bit state stored at address.
 */
bool validate_state(const uint16_t addr) {
    gen_st gst;
    read_state(addr, &gst.state, &gst.not_state);
    if (state_is_valid(&gst))
        return true;
    return false;
}

/*
 * 8-bit integrity check: value must equal bitwise inverse of stored not_state.
 */
bool state_is_valid(const gen_st *gst) {
    return gst->state == (uint8_t) ~gst->not_state;
}

/*
 * Validate 16-bit state stored at address.
 */
bool validate_state16(const uint16_t addr) {
    gen_st16 gst;
    read_state16(addr, &gst.state, &gst.not_state);
    if (state16_is_valid(&gst))
        return true;
    return false;
}

/*
 * 16-bit integrity check.
 */
bool state16_is_valid(const gen_st16 *gst) {
    return gst->state == (uint16_t) ~gst->not_state;
}

/*
 * Write a log entry with CRC16.
 * Format:
 *   [string bytes][null terminator][CRC high][CRC low]
 */
void write_log_entry(char *log) {
    const int log_len = (int)strnlen(log, LOG_MAX_LEN);
    if (log_len <= LOG_MAX_LEN) {
        uint8_t buffer[LOG_ENTRY_SIZE];
        // Copy string
        memcpy(buffer, log, log_len);
        buffer[log_len] = '\0';
        // CRC is calculated for the string and end mark
        const uint16_t crc = crc16(buffer, log_len + 1);
        buffer[log_len + 1] = crc >> 8 & 0xFF;
        buffer[log_len + 2] = crc & 0xFF;

        const int total_log_len = log_len + 3;
        const uint16_t start_index = next_log_index();
        write_log_bytes(start_index, buffer, total_log_len);

        send_msg(log);
        printf("%s.\r\n", log);
    }
}

/*
 * Low-level variable-length log write.
 * Writes: [2-byte address][data bytes]
 */
void write_log_bytes(uint16_t const address, const uint8_t *data, const int total_log_len) {
    uint8_t log_entry[2 + LOG_ENTRY_SIZE];
    log_entry[0] = address >> 8 & 0xFF; // MSB (Most Significant Byte) address
    log_entry[1] = address & 0xFF; // LSB (Least Significant Byte) address
    memcpy(&log_entry[2], data, total_log_len); // Actual data

    i2c_write_blocking(I2C, EEPROM_ADDRESS, log_entry, 2 + total_log_len, false);
    sleep_ms(WB_SLEEP_MS);
}

/*
 * Find next free log slot. If all log slots are valid, erase entire log area.
 */
uint16_t next_log_index() {
    uint16_t addr = 0;
    for (int i = 0; i < MAX_LOGS; i++) {
        if (!validate_log_entry(addr)) {
            return addr;
        }
        addr += LOG_ENTRY_SIZE;
    }
    erase_log_entries();
    return 0;
}

/*
 * Validate a log entry by:
 *  - finding null terminator
 *  - calculating CRC
 *  - comparing CRC to stored CRC
 */
bool validate_log_entry(const uint16_t addr) {
    uint8_t buffer[LOG_ENTRY_SIZE];
    read_log_entry(addr, buffer);
    if (buffer[0] != 0) {
        bool end_mark = false;
        int index = 0;

        do {
            if (buffer[index] == '\0')
                end_mark = true;
            else index++;
        } while (index <= LOG_MAX_LEN && !end_mark);

        const size_t total_len = index + 3;
        if (end_mark && total_len <= LOG_ENTRY_SIZE) {
            const uint16_t crc = crc16(buffer, total_len);
            return crc == 0;
        }
    }
    return false;
}

/*
 * Print all valid log entries in order.
 */
void print_log_entries() {
    uint16_t j = 0;
    for (int i = 0; i < MAX_LOGS; i++) {
        if (validate_log_entry(j)) {
            uint8_t buffer[LOG_ENTRY_SIZE];
            read_log_entry(j, buffer);
            printf("%d. log: %s\r\n", i + 1, (char*)buffer);
        }
        j += LOG_ENTRY_SIZE;
    }
}

/*
 * Read a log entry block from EEPROM.
 */
void read_log_entry(const uint16_t addr, uint8_t *buffer) {
    uint8_t addr_part[2];
    addr_part[0] = addr >> 8 & 0xFF; // MSB
    addr_part[1] = addr & 0xFF; // LSB
    i2c_write_blocking(I2C, EEPROM_ADDRESS, addr_part, 2,true);
    i2c_read_blocking(I2C, EEPROM_ADDRESS, buffer, LOG_ENTRY_SIZE, false);
}

/*
 * Erase entire log storage by writing '\0' at start of each entry.
 */
void erase_log_entries() {
    printf("Erase log entries.\r\n");
    int j = 0;
    for (int i = 0; i < MAX_LOGS; i++) {
        write_byte(j, '\0');
        j += LOG_ENTRY_SIZE;
    }
}

/*
 * CRC16 used for log entry verification.
 */
uint16_t crc16(const uint8_t *data_p, size_t length) {
    uint16_t crc = 0xFFFF;
    while (length--) {
        uint8_t x = crc >> 8 ^ *data_p++;
        x ^= x >> 4;
        crc = crc << 8 ^ (uint16_t) (x << 12) ^ (uint16_t) (x << 5) ^ (uint16_t) x;
    }
    return crc;
}

/*
 * Initialize all persistent modules.
 * Called once at system startup.
 */
void init_memory() {
    init_pill_count_st();
    init_led_states();
}

/*
 * Write a single byte to EEPROM.
 */
void write_byte(uint16_t const address, uint8_t const value) {
    uint8_t buffer[3];
    // Split 16-bit EEPROM address into MSB and LSB because I2C transfers only 8-bit bytes
    buffer[0] = address >> 8 & 0xFF; // MSB (Most Significant Byte) address
    buffer[1] = address & 0xFF; // LSB (Least Significant Byte) address
    buffer[2] = value; // Actual data, one byte
    // Write the address and data to the EEPROM
    // Send 3 bytes: 2 byte of address and 1 byte of data
    i2c_write_blocking(I2C, EEPROM_ADDRESS, buffer, 3, false);
    sleep_ms(WB_SLEEP_MS);
}

/*
 * Read a single byte from EEPROM.
 */
uint8_t read_byte(uint16_t const address) {
    uint8_t buffer[2];
    uint8_t data;
    // Split 16-bit EEPROM address into MSB and LSB because I2C transfers only 8-bit bytes
    buffer[0] = address >> 8 & 0xFF; // MSB (Most Significant Byte) address
    buffer[1] = address & 0xFF; // LSB (Least Significant Byte) address
    i2c_write_blocking(I2C, EEPROM_ADDRESS, buffer, 2,true); // Send address to EEPROM
    i2c_read_blocking(I2C, EEPROM_ADDRESS, &data, 1, false); // Read one byte from the EEPROM address
    return data;
}