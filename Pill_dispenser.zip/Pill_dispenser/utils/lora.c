// LoRa UART/I2C initialization, cmd handling and join state machines
#include "lora.h"
#include "eeprom.h"
#include "tools.h"

/*
 * Initialize UART interface for LoRa module.
 * - Configures UART1
 * - Sets TX/RX pins to UART mode
 * - Uses format 8 data bits, 1 stop bit, no parity (8N1)
 */
void init_uart() {
    // Initialize UART1 for LoRa module
    uart_init(UART, BAUD_RATE_UART);
    gpio_set_function(UART_TX, GPIO_FUNC_UART);
    gpio_set_function(UART_RX, GPIO_FUNC_UART);
    // Set UART frame format to 8 data bits, 1 stop bit and no parity (8N1)
    uart_set_format(UART, 8, 1, UART_PARITY_NONE);
    uart_set_fifo_enabled(UART, true);
}

/*
 * Initialize I2C bus used by the LoRa module and EEPROM.
 * - Sets SDA/SCL pins to I2C mode
 * - Enables pull-ups on each I2C pin
 */
void init_i2c() {
    // Initialize the I2C controller
    i2c_init(I2C, BAUD_RATE_I2C);
    for (int i = 0; i < I2C_SIZE; i++) {
        gpio_set_function(i2cs[i], GPIO_FUNC_I2C);
        gpio_pull_up(i2cs[i]);
    }
}

/*
 * Run UART-based connectivity state machine to verify LoRa module is responding.
 * Returns true if module passes all checks (AT, VERSION, DEV_EUI).
 */
bool check_lora_comm() {
    uart_sm tsm = { check_connection_st };
    bool start_st = true;
    bool connected = false;
    while (start_st) {
        check_uart_sm(&tsm, &start_st, &connected);
    }
    if (connected)
        return true;
    return false;
}

/*
 * Run LoRaWAN join procedure using a state machine.
 * Executes all required LoRa configuration commands.
 */
void join_network() {
    lora_sm lsm = { mode_st };
    bool start_st = true;
    while (start_st) {
        lora_join_sm(&lsm, &start_st);
    }
}

/*
 * LoRaWAN join state machine.
 * Steps:
 *  1. Set mode
 *  2. Set application key
 *  3. Set class A
 *  4. Set port
 *  5. Join network
 */
void lora_join_sm(lora_sm *lsm, bool *continue_loop) {
    switch (lsm->state) {
        case mode_st:
            if (run_lora_cmd(CMD_MODE, CMD_MODE_RETURN, CMD_MS))
                lsm->state = key_st;
            else
                lsm->state = stop_lora_st;
            break;
        case check_version_st:
            if (run_lora_cmd(CMD_APP_KEY, CMD_APP_KEY_RETURN, CMD_MS))
                lsm->state = class_st;
            else
                lsm->state = stop_lora_st;
            break;
        case class_st:
            if (run_lora_cmd(CMD_CLASS_A, CMD_CLASS_A_RETURN, CMD_MS))
                lsm->state = port_st;
            else
                lsm->state = stop_lora_st;
            break;
        case port_st:
            if (run_lora_cmd(CMD_PORT, CMD_PORT_RETURN, CMD_MS))
                lsm->state = join_st;
            else
                lsm->state = stop_lora_st;
            break;
        case join_st:
            join_lora();
            lsm->state = stop_lora_st;
            break;
        case stop_lora_st:
            lsm->state = mode_st;
            *continue_loop = false;
    }
}

/*
 * Retries LoRaWAN join operation up to 5 times.
 */
void join_lora() {
    int count = 0;
    bool continue_loop = true;
    do {
        if (count < 5) {
            if (return_lora())
                continue_loop = false;
        }
        else
            continue_loop = false;
        count++;
    } while (continue_loop);
}

/*
 * Sends join command and waits for either successful or failed response.
 */
bool return_lora() {
    char line[LINE_LEN];
    write_str(CMD_JOIN);
    for (int i = 0; i < 5; i++) {
        if (read_line(line, sizeof(line), JOIN_MS)) {
            if (strcmp(line, CMD_JOIN_RETURN_TRUE) == 0) {
                printf("Joined to LoRaWAN network.\r\n");
                return true;
            }
            if (strcmp(line, CMD_JOIN_RETURN_FALSE) == 0) {
                printf("Connecting to LoRaWAN network failed.\r\n");
                return false;
            }
        }
    }
    return false;
}

/*
 * Send LoRa command and check return string.
 * Returns true if expected response is found.
 */
bool run_lora_cmd(const char *cmd, const char *return_msg, const int timeout_ms) {
    char line[LINE_LEN];
    for (int i = 0; i < 5; i++) {
        write_str(cmd);
        if (read_line(line, sizeof(line), timeout_ms)) {
            if (strstr(line, return_msg) != NULL)
                return true;
        }
    }
    return false;
}

/*
 * Send text message through LoRaWAN uplink.
 * CMD_MSG + quoted text is transmitted.
 */
void send_msg(char *msg_str) {
    char message[LOG_ENTRY_SIZE];
    snprintf(message, sizeof(message), "%s\"%s\"", CMD_MSG, msg_str);
    char line[LINE_LEN];
    write_str(message);
    for (int i = 0; i < 5; i++) {
        if (read_line(line, sizeof(line), SEND_MSG_MS)) {
            if (strcmp(line, CMD_MSG_RETURN) == 0)
                return;
        }
    }
}

/*
 * UART-based connectivity state machine.
 * Steps:
 *  1. Check AT response
 *  2. Check version
 *  3. Check DevEUI
 * Sets *connected = true if all checks succeed.
 */
void check_uart_sm(uart_sm *smi, bool *continue_loop, bool *connected) {
    switch (smi->state) {
        case check_connection_st:
            if (run_lora_cmd(CMD_AT, CMD_AT_RETURN, CMD_MS)) {
                printf("Connected to LoRa module\r\n");
                smi->state = check_version_st;
            }
            else {
                printf("Module not responding\r\n");
                smi->state = stop_st;
            }
            break;
        case check_version_st:
            if (run_lora_cmd(CMD_VERSION, CMD_VERSION_RETURN, CMD_MS))
                smi->state = check_dev_eui_st;
            else {
                printf("Module stopped responding\r\n");
                smi->state = stop_st;
            }
            break;
        case check_dev_eui_st:
            if (run_lora_cmd(CMD_DEV_EUI, CMD_DEV_EUI_RETURN, CMD_MS)) {
                smi->state = check_connection_st;
                *connected = true;
                *continue_loop = false;
            }
            else {
                printf("Module stopped responding\r\n");
                smi->state = stop_st;
            }
            break;
        case stop_st:
            smi->state = check_connection_st;
            *continue_loop = false;
            break;
    }
}