#ifndef APP_SM_H
#define APP_SM_H

#include "stdint.h"
#include "../main.h"

/*
 * --- Timing configuration for state machine behaviour ---
 * WAITING_PILL_TO_DROP_MAX:
 *      Maximum time allowed for a pill to fall after a motor step.
 *
 * BLINK_LIGHT_TIMES / BLINKING_LIGHT_MS:
 *      LED feedback pattern for pill_not_dropped_state.
 *
 * PILL_NOT_DROPPED_MAX:
 *      Total duration of the blinking sequence.
 *
 * BLINKING_LIGHT_INITIAL_ST_MS:
 *      LED blink rate while device is in initial_state.
 *
 * WAIT_TURN_MAX:
 *      Delay between dispensing cycles (shortened for testing).
 */
#define WAITING_PILL_TO_DROP_MAX 2000 // how long to wait for the pill to drop
#define BLINK_LIGHT_TIMES 5
#define BLINKING_LIGHT_MS 100
#define PILL_NOT_DROPPED_MAX (BLINK_LIGHT_TIMES * 2 * BLINKING_LIGHT_MS - 50)

#define BLINKING_LIGHT_INITIAL_ST_MS 1000

#define WAIT_TURN_MAX 2000 // 30 seconds.

/*
 * Enumeration of all application state machine states.
 * Each state has a dedicated handler function in sm.c.
 */
typedef enum {
    initial_state = 0, // Power-on, idle blinking
    calib_state = 1, // Stepper motor calibration
    idle_state = 2, // Waiting for input or scheduled dispensing
    pill_dispensing_state = 3, // Motor turn + immediate pill detection
    waiting_pill_to_drop_state = 4, // Grace period for delayed pill fall
    pill_not_dropped_state = 5, // Error: pill expected but missing
    wait_turn_state = 6, // Delay between dispensing cycles
    re_calib_state = 7 // Post–power outage recalibration
} current_st;

/*
 * Generic function pointer type for state handlers.
 */
typedef void (*AppState)();

/*
 * Struct used to store state values redundantly in EEPROM.
 * `state` contains the actual value; `not_state` contains bitwise inverse.
 */
typedef struct sm_state {
    uint8_t state;
    uint8_t not_state;
} sm_state;

/*
 * Legacy wrapper for main state storage (kept for compatibility).
 */
typedef struct main_sm_state {
    uint8_t state;
} main_sm_state;

/*
 * --- State machine interface (implemented in sm.c) ---
 */
void run_sm();
void next_state(current_st state);
void initial_st();
void calib_st();
void idle_st();
void pill_dispensing_st();
void waiting_pill_to_drop_st();
void pill_not_dropped_st();
void wait_turn_st();
void re_calib_st();

bool check_st(current_st state);
void write_current_st(uint8_t value);

int read_current_st();
void set_sm_state(sm_state *sms, uint8_t value);
bool validate_current_st(const sm_state *sms);
void init_current_st();
char *char_st(current_st cst);
void state_change_info(char *state_str);
bool can_press();

/*
 * Lookup table mapping enum values to their handler functions.
 * run_sm() uses current_state as an index to this table.
 */
static const AppState states[] = {
    [initial_state] = initial_st,
    [calib_state] = calib_st,
    [idle_state] = idle_st,
    [pill_dispensing_state] = pill_dispensing_st,
    [waiting_pill_to_drop_state] = waiting_pill_to_drop_st,
    [pill_not_dropped_state] = pill_not_dropped_st,
    [wait_turn_state] = wait_turn_st,
    [re_calib_state] = re_calib_st
};

#endif