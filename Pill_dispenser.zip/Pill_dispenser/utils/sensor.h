#ifndef SENSOR_H
#define SENSOR_H

#include "hardware/adc.h"

#define PIEZO_SENSOR 27 // Piezo sensor input with pull-up
#define OPTO_FORK 28 // Optical sensor input with pull-up
#define SENSORS_SIZE 2
static const uint sensors[] = {PIEZO_SENSOR, OPTO_FORK};

void init_sensors();
bool piezo_sensor_detect();

#endif