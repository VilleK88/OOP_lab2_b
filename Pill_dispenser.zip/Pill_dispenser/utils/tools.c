#include "ctype.h"
#include "tools.h"
#include "lora.h"

//------------------------------------------------------------
// Send a null-terminated C-string to the LoRa module over UART.
// Each character is sent raw, followed by CRLF ("\r\n") to
// complete the AT-command format required by the LoRa-E5 module.
//------------------------------------------------------------
void write_str(const char *string) {
    while (*string) {
        uart_putc_raw(UART, *string++);
    }
    uart_putc_raw(UART, '\r');
    uart_putc_raw(UART, '\n');
}

//------------------------------------------------------------
// Read one full line from UART into 'buffer' with a timeout.
// - 'len' specifies maximum allowed characters (buffer size).
// - 'timeout_ms' is converted to microseconds for the Pico SDK.
// - Reads until '\n' is encountered.
// - '\r' characters are ignored.
// - Returns true if a line was successfully read,
//   false if the timeout expires before receiving data.
//------------------------------------------------------------
bool read_line(char *buffer, const int len, const int timeout_ms) {
    const uint32_t us = timeout_ms * 1000; // convert to microseconds
    // Wait for data to become available within timeout
    int i = 0;
    while (i <= len) {
        if (uart_is_readable_within_us(UART, us)) {
            const char c = uart_getc(UART);
            if (c != '\n') {
                if (c != '\r') // Ignore carriage return
                    buffer[i++] = c;
            }
            else break; // End of line
        }
        else return false; // No data received within timeout
    }
    buffer[i] = '\0'; // Null-terminate resulting string
    return true;
}

//------------------------------------------------------------
// Extract the DevEui part from a LoRa AT response and print it
// as a continuous lowercase hexadecimal string.
//
// Example input:
//     "+ID: DevEui, 11:22:33:44:55:66:77:88"
// Output:
//     1122334455667788
//
// Steps:
// - Find the comma in the string.
// - Skip the comma and space to reach first hex digit.
// - Iterate through characters, collecting hex digits until ':'
//   or newline, print each complete two-digit hex group.
//------------------------------------------------------------
bool convert_and_print(const char *line) {
    if (strchr(line, ',') != NULL) {
        char *line_after_comma = strchr(line, ','); // Find comma after "DevEui"
        line_after_comma += 2; // Skip ", " to point at first hex digit
        strcat(line_after_comma, "\n");
        const int len = (int)strlen(line_after_comma);
        char current_hexadecimal[4]; // Temporary buffer for each group
        int j = 0;
        for (int i = 0; i < len; i++) {
            // Copy characters until ':' or '\n' or temporary buffer is full
            if (line_after_comma[i] != ':' && line_after_comma[i] != '\n') {
                current_hexadecimal[j++] = tolower((unsigned char)line_after_comma[i]);
            }
            else {
                // Terminate current group and print it
                current_hexadecimal[j] = '\0';
                printf("%s", current_hexadecimal);
                j = 0;
            }
        }
        printf("\r\n");
        return true;
    }
    return false;
}

//------------------------------------------------------------
// Return milliseconds since boot using the Pico SDK.
//------------------------------------------------------------
uint32_t get_ms() {
    return to_ms_since_boot(get_absolute_time());
}

//------------------------------------------------------------
// Timestamp helper used by the state machine.
// If the stored timestamp is invalid, this initializes it with
// the current time and marks it as valid.
//------------------------------------------------------------
void validate_and_reset_ms(bool *last_ms_valid, uint32_t *last_ms, const uint32_t *now_ms) {
    if (!*last_ms_valid) {
        *last_ms = *now_ms; // Reset timestamp
        *last_ms_valid = true;
    }
}

//------------------------------------------------------------
// Clear all pending events in the global event queue.
// Discards events until queue is empty.
//------------------------------------------------------------
void discard_events() {
    event_t discarded_event;
    // Clears the queue
    while (queue_try_remove(&events, &discarded_event)) {}
}