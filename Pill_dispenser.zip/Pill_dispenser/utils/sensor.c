#include "../main.h"
#include "sensor.h"

static event_t event;

void init_sensors() {
    // Initialize piezo and optical sensor input (with internal pull-up)
    for (int i = 0; i < SENSORS_SIZE; i++) {
        gpio_init(sensors[i]);
        gpio_set_dir(sensors[i], GPIO_IN);
        gpio_pull_up(sensors[i]);
    }

    // Configure button interrupt and callback for Piezo sensor
    gpio_set_irq_enabled_with_callback(PIEZO_SENSOR, GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL,
        true, &gpio_callback);
}

bool piezo_sensor_detect() {
    // Process all pending events from the queue
    while (queue_try_remove(&events, &event)) {
        if (event.type == EV_PIEZO) {
            return true;
        }
    }
    return false;
}
