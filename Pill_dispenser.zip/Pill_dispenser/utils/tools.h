#ifndef TOOLS_H
#define TOOLS_H

#include "../main.h"

void write_str(const char *string); // Send a null-terminated string over UART
bool read_line(char *buffer, int len, int timeout_ms); // Read one line from UART with timeout
bool convert_and_print(const char *line); // Convert DevEui response to required format
uint32_t get_ms(); // Returns the number of milliseconds elapsed since system startup
void validate_and_reset_ms(bool *last_ms_valid, uint32_t *last_ms, const uint32_t *now_ms);
void discard_events(); // Clears the queue

#endif