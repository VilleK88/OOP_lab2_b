#ifndef UART_STATES_H
#define UART_STATES_H

#include "../main.h"

// UART instance and GPIO pin definitions for the LoRa-E5 module
#define UART uart1 // Use UART1 hardware block
#define UART_TX 4 // UART1 TX pin (GP4) → LoRa module RX
#define UART_RX 5 // UART1 RX pin (GP5) ← LoRa module TX

#define BAUD_RATE_UART 9600 // UART speed for LoRa module communication

#define LINE_LEN 128 // Maximum UART line buffer length for received data

/*
 * LoRa-E5 AT command definitions and expected return tokens.
 * These strings are used to configure the LoRa module and to verify responses.
 */

// Basic UART connectivity check
#define CMD_AT "AT"
#define CMD_AT_RETURN "OK"

// Firmware version
#define CMD_VERSION "AT+VER"
#define CMD_VERSION_RETURN "VER"

// Device EUI
#define CMD_DEV_EUI "AT+ID=DevEui"
#define CMD_DEV_EUI_RETURN "DevEui"

// Set LoRaWAN mode (Over-The-Air Activation)
#define CMD_MODE "AT+MODE=LWOTAA"
#define CMD_MODE_RETURN "LWOTAA"

// Application key for OTAA join procedure
#define CMD_APP_KEY "AT+KEY=APPKEY, 93afdd36879296b1ca22e2923d60dddf"
#define CMD_APP_KEY_RETURN "+KEY: APPKEY"

// Set LoRaWAN class
#define CMD_CLASS_A "AT+CLASS=A"
#define CMD_CLASS_A_RETURN "+CLASS: A"

// Set application port
#define CMD_PORT "AT+PORT=8"
#define CMD_PORT_RETURN "+PORT: 8"

// Join network
#define CMD_JOIN "AT+JOIN"
#define CMD_JOIN_RETURN_TRUE "+JOIN: Network joined"
#define CMD_JOIN_RETURN_FALSE "+JOIN: Join failed"

// Send uplink message
#define CMD_MSG "AT+MSG="
#define CMD_MSG_RETURN "+MSG: Done"

// Timeouts for various commands (milliseconds)
#define CMD_MS 500
#define JOIN_MS 20000 // Join requires long timeout due to network OTAA process
#define SEND_MSG_MS 1250 // Uplink transmission completion time

/*
 * UART state machine states for module verification.
 * Steps:
 *   1. AT connectivity test
 *   2. Version check
 *   3. DevEUI check
 */
typedef enum {
    check_connection_st,
    check_version_st,
    check_dev_eui_st,
    stop_st
} uart_st;

/*
 * Container for UART connectivity state machine.
 */
typedef struct uart_sm {
    uart_st state;
} uart_sm;

/*
 * LoRaWAN join state machine states.
 * Each step sends one AT command.
 */
typedef enum {
    mode_st,
    key_st,
    class_st,
    port_st,
    join_st,
    stop_lora_st
} lora_st;

/*
 * Container for join-procedure state machine.
 */
typedef struct lora_sm {
    lora_st state;
} lora_sm;

/*
 * Generic 1-byte state + inverted copy for EEPROM integrity checking.
 * Used for join-related persistent states (if needed).
 */
typedef struct join_state {
    uint8_t state;
    uint8_t not_state;
} join_state;

void init_uart();
void init_i2c();
bool check_lora_comm();
void join_network();
void lora_join_sm(lora_sm *lsm, bool *continue_loop);
void join_lora();
bool return_lora();
bool run_lora_cmd(const char *cmd, const char *return_msg, int timeout_ms);
void send_msg(char *msg_str);
void check_uart_sm(uart_sm *smi, bool *continue_loop, bool *connected);

#endif