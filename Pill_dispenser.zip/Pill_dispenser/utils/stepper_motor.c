// Stepper motor control, calibration and persistent state handling
#include "stepper_motor.h"
#include "sensor.h"
#include "eeprom.h"
#include "lights.h"

// Stores the number of half-steps per full revolution. Loaded from EEPROM after startup.
static int steps_per_rev = DEFAULT_STEPS_PER_REV;

/*
 * Initialize GPIO pins used to drive the stepper motor coils.
 * All pins are configured as outputs and set LOW to ensure the motor
 * starts in a known and safe state.
 */
void init_coil_pins() {
    // Initialize all coil pins as outputs and set them LOW at startup
    for (int i = 0; i < INS_SIZE; i++) {
        gpio_init(coil_pins[i]);
        gpio_set_dir(coil_pins[i], GPIO_OUT);
        gpio_put(coil_pins[i], 0); // Ensure coils are off at startup
    }
}

/*
 * Full calibration procedure:
 *  - Rotates the motor forward
 *  - Detects two falling edges from the opto-fork
 *  - Measures step count between edges (one full revolution)
 *  - Stores steps_per_rev and other calibration data to EEPROM
 *  - Realigns the motor to a known home position
 */
void calibrate() {
    int count = 0; // Number of falling edges detected
    int step = 0; // total half-steps taken
    int edge_step = 0; // Steps between consecutive edges (starts after first edge)
    bool first_edge_found = false;
    bool continue_loop = true;
    bool prev_state = gpio_get(OPTO_FORK); // true = no obstacle, false = obstacle
    write_state(STEP_MOTOR_ADDR, STEP_MOTOR_ON);
    state_change_info("Calibrating");

    do {
        // Advance the motor by one half-step
        step_motor(1);
        sleep_ms(MOTOR_SLEEP_MS);
        step++;

        // Start counting steps between edges after the first edge has been found
        if (first_edge_found)
            edge_step++;

        const bool sensor_state = gpio_get(OPTO_FORK);

        // Detect falling edge: HIGH -> LOW transition (no obstacle -> obstacle)
        if (prev_state && !sensor_state) {
            if (!first_edge_found) {
                // First falling edge - start counting after this point
                first_edge_found = true;
            }
            else {
                // Store number of steps between consecutive edge
                steps_per_rev = edge_step;
            }
            count++;
        }
        // Stop after 2 falling edges (1 interval) or reaching safety limit
        if (count >= FALLING_EDGE_MAX || step > CALIB_SAFE_MAX)
            continue_loop = false;

        prev_state = sensor_state;

    } while (continue_loop);

    // At least 2 edges are required to compute 1 interval
    if (count >= FALLING_EDGE_MAX) {
        write_state(CALIB_STATUS_ADDR, CALIB_TRUE);
        write_state16(STEPS_PER_REV_ADDR, steps_per_rev);
        write_state(MOTOR_COUNT_ADDR, 0);

        motor_realignment_procedure(1);

        if (!light_on(LED_M_ADDR))
            light_switch(LED_M, LED_M_ADDR);

        state_change_info("Calibration completed -> Idle state");
        printf("Steps per revolution: %d.\r\n", steps_per_rev);
        next_state(idle_state);
    }
    else {
        write_state(STEP_MOTOR_ADDR, STEP_MOTOR_OFF);
        write_state(CALIB_STATUS_ADDR, CALIB_FALSE);
        state_change_info("Calibration failed -> Initial state");
        next_state(initial_state);
    }
}

/*
 * Repositions the motor to a known mechanical zero point after calibration
 * by rotating a fixed number of steps in the specified direction.
 */
void motor_realignment_procedure(const int direction) {
    for (int i = 0; i < 168; i++) {
        step_motor(direction);
        sleep_ms(MOTOR_SLEEP_MS);
    }
    write_state(STEP_MOTOR_ADDR, STEP_MOTOR_OFF);
}

/*
 * Special calibration procedure used only after a power outage.
 * The motor moves backwards until one falling edge is detected.
 * After realignment, any unfinished dispensing movement is restored.
 */
void calib_after_power_outage() {
    int count = 0; // Number of falling edges detected
    int step = 0; // total half-steps taken
    bool continue_loop = true;
    bool prev_state = gpio_get(OPTO_FORK); // true = no obstacle, false = obstacle
    write_state(STEP_MOTOR_ADDR, STEP_MOTOR_ON);
    state_change_info("Calibrating after power outage");

    do {
        // Advance the motor by one half-step
        step_motor(-1);
        sleep_ms(MOTOR_SLEEP_MS);
        step++;

        const bool sensor_state = gpio_get(OPTO_FORK);
        // Detect falling edge: HIGH -> LOW transition (no obstacle -> obstacle)
        if (prev_state && !sensor_state) {
            count++;
        }
        // Stop after 1 falling edge or by reaching calib safe max
        if (count >= POWER_OUTAGE_FALLING_EDGE_MAX || step > CALIB_SAFE_MAX)
            continue_loop = false;

        prev_state = sensor_state;

    } while (continue_loop);

    if (count >= POWER_OUTAGE_FALLING_EDGE_MAX) {
        write_state(CALIB_STATUS_ADDR, CALIB_TRUE);

        motor_realignment_procedure(-1);

        gen_st gst;
        read_state(MOTOR_COUNT_ADDR, &gst.state, &gst.not_state);
        for (int i = 0; i < gst.state; i++) {
            run_motor(1);
        }

        if (!light_on(LED_M_ADDR))
            light_switch(LED_M, LED_M_ADDR);

        state_change_info("Calibration completed -> Pill dispensing state");
        printf("Steps per revolution: %d.\r\n", steps_per_rev);
        next_state(pill_dispensing_state);
    }
    else {
        write_state(STEP_MOTOR_ADDR, STEP_MOTOR_OFF);
        write_state(CALIB_STATUS_ADDR, CALIB_FALSE);
        state_change_info("Calibration failed -> Initial state");
        next_state(initial_state);
    }
}

/*
 * Executes a single half-step sequence for the stepper motor.
 * The `direction` parameter determines rotation (1 = forward, -1 = backward).
 */
void step_motor(const int direction) {
    // Half-step sequence for unipolar stepper motor
    // Each row defines which coils (IN1–IN4) are energized for each step
    const int half_step[8][4] = {
        {1, 0, 0, 0}, // Step 1: A
        {1, 1, 0, 0}, // Step 2: A + B
        {0, 1, 0, 0}, // Step 3: B
        {0, 1, 1, 0}, // Step 4: B + C
        {0, 0, 1, 0}, // Step 5: C
        {0, 0, 1, 1}, // Step 6: C + D
        {0, 0, 0, 1}, // Step 7: D
        {1, 0, 0, 1}  // Step 8: D + A
    };

    // Determines which step phase (0–7) the motor is currently in
    // Bitwise AND preserves only the three lowest bits
    static int phase = 0;
    phase = phase + direction & 7;
    for (int i = 0; i < INS_SIZE; i++) {
        gpio_put(coil_pins[i], half_step[phase][i]);
    }
}

/*
 * Runs the stepper motor for `count` full dispenser turns.
 * One turn = steps_per_rev half-steps.
 */
void run_motor(const int count) {
    write_state(STEP_MOTOR_ADDR, STEP_MOTOR_ON);
    // Calculate total number of half-steps:
    const int i_count = count * (steps_per_rev / 8);
    for (int i = 0; i < i_count; i++) {
        step_motor(1);
        sleep_ms(MOTOR_SLEEP_MS);
    }
    write_state(STEP_MOTOR_ADDR ,STEP_MOTOR_OFF);
}

/*
 * Stores a 1-byte motor state with inverted integrity byte.
 */
void set_step_motor_state(step_motor_st *sms, const uint8_t value) {
    sms->state = value;
    sms->not_state = ~value;
}

/*
 * Initializes motor states and restores machine behavior after reboot.
 * Handles three scenarios:
 *   - invalid EEPROM state → reset
 *   - power outage during movement → recover
 *   - normal startup → restore state and steps_per_rev
 */
void init_step_motor_st(const bool valid) {
    if (!valid) {
        write_state(STEP_MOTOR_ADDR, STEP_MOTOR_OFF);
        write_state(MOTOR_COUNT_ADDR, 0);
        write_state(CALIB_STATUS_ADDR, CALIB_FALSE);
        write_state16(STEPS_PER_REV_ADDR, DEFAULT_STEPS_PER_REV);
        next_state(initial_state);
    }
    else {
        if (motor_on()) {
            write_log_entry("Power outage occurred while the motor was running");
            init_current_st();
            if (check_st(pill_dispensing_state)) {
                if (calibration_status())
                    init_steps_per_rev();
                next_state(re_calib_state);
            }
            else if (check_st(calib_state)) {
                next_state(calib_state);
            }
            else if (check_st(re_calib_state)) {
                motor_realignment_procedure(1);
                next_state(re_calib_state);
            }
        }
        else {
            if (calibration_status())
                init_steps_per_rev();
            init_current_st();
        }
    }
}

/*
 * Load steps_per_rev from EEPROM after system restart.
 */
void init_steps_per_rev() {
    gen_st16 gst;
    read_state16(STEPS_PER_REV_ADDR, &gst.state, &gst.not_state);
    steps_per_rev = (int)gst.state;
}

/*
 * Returns true if motor was running before the last shutdown.
 */
bool motor_on() {
    if (read_byte(STEP_MOTOR_ADDR) == STEP_MOTOR_ON)
        return true;
    return false;
}

/*
 * Read steps_per_rev from EEPROM (8-bit version, legacy).
 */
int read_steps_per_rev() {
    gen_st gst;
    read_state(STEPS_PER_REV_ADDR, &gst.state, &gst.not_state);
    if (state_is_valid(&gst))
        return gst.state;
    return DEFAULT_STEPS_PER_REV;
}

/*
 * Read how many motor turns have already completed in the current dispense cycle.
 */
int read_motor_count() {
    gen_st gst;
    read_state(MOTOR_COUNT_ADDR, &gst.state, &gst.not_state);
    if (state_is_valid(&gst))
        return gst.state;
    return 0;
}

/*
 * Returns true if calibration was marked as successful.
 */
bool calibration_status() {
    gen_st gst;
    read_state(CALIB_STATUS_ADDR, &gst.state, &gst.not_state);
    if (gst.state == CALIB_TRUE)
        return true;
    return false;
}