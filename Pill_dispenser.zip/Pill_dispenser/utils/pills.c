#include "pico/stdlib.h"
#include "pills.h"
#include "eeprom.h"

/*
 * Handle pill dispensing result.
 * If a pill was detected, decrement counter and log outcome.
 * If no pill or counter already zero, only log the event.
 */
void process_pill_dispense(const bool pill) {
    int pills_count = read_pills_count();
    if (pill) {
        if (pills_count > 0) {
            pills_count--;
            write_pills_count(pills_count);
            add_pill_log_entry(pills_count, true);
        }
        else
            add_pill_log_entry(pills_count, false);
    }
    else
        add_pill_log_entry(pills_count, false);
}

/*
 * Refill pill container when empty and write new count to EEPROM.
 * Generates a log entry whenever a refill occurs.
 */
void fill_the_pills(const int pills_count) {
    if (pills_count <= 0) {
        pills_state ps;
        set_pills_state(&ps, MAX_PILLS);
        write_state_bytes(PILLS_COUNT_ADDR, ps.state, ps.not_state);
        char log_entry[LOG_ENTRY_SIZE];
        snprintf(log_entry, sizeof(log_entry), "Pills filled. Pills left: %d", MAX_PILLS);
        write_log_entry(log_entry);
    }
}

/*
 * Helper function to build redundant pill count pair (value + bitwise inverse).
 */
void set_pills_state(pills_state *ps, const uint8_t value) {
    ps->state = value;
    ps->not_state = ~value;
}

/*
 * Read pill count from EEPROM and validate integrity.
 * Returns valid value or 0 on corruption.
 */
int read_pills_count() {
    pills_state ps;
    read_state(PILLS_COUNT_ADDR, &ps.state, &ps.not_state);
    if (pills_state_is_valid(&ps)) {
        return ps.state;
    }
    return 0;
}

/*
 * Initialize pill count on system startup.
 * If stored data is invalid, refill container automatically.
 */
void init_pill_count_st() {
    pills_state ps;
    read_state(PILLS_COUNT_ADDR, &ps.state, &ps.not_state);
    if (!pills_state_is_valid(&ps)) {
        fill_the_pills(MAX_PILLS);
    }
}

/*
 * Store new pill count in EEPROM with redundant encoding.
 */
void write_pills_count(const int pills_count) {
    pills_state ps;
    set_pills_state(&ps, (uint8_t)pills_count);
    write_state_bytes(PILLS_COUNT_ADDR, ps.state, ps.not_state);
}

/*
 * Record whether a pill dropped during the last dispensing attempt.
 */
void write_pill_dropped_st(const bool dropped) {
    pills_state ps;
    set_pills_state(&ps, dropped);
    write_state_bytes(PILL_DROPPED_ADDR, ps.state, ps.not_state);
}

/*
 * Read last pill-dropped flag from EEPROM.
 * Returns true/false on valid data, false on data corruption.
 */
bool read_if_pill_dropped() {
    pills_state ps;
    read_state(PILL_DROPPED_ADDR, &ps.state, &ps.not_state);
    if (pills_state_is_valid(&ps)) {
        if (ps.state == PILL_TRUE)
            return true;
        return false;
    }
    return false;
}

/*
 * Validate pill-state redundancy pair.
 */
bool pills_state_is_valid(const pills_state *ps) {
    return ps->state == (uint8_t) ~ps->not_state;
}

/*
 * Format and append pill dispensing log entry.
 * Logged whether a pill was dispensed or not.
 */
void add_pill_log_entry(const int pills_left, const bool pill_dis) {
    char log_entry[LOG_ENTRY_SIZE];
    if (pill_dis)
        snprintf(log_entry, sizeof(log_entry), "Pill dispensed. Pills left: %d/%d", pills_left, MAX_PILLS);
    else
        snprintf(log_entry, sizeof(log_entry), "No pill was dispensed. Pills left: %d/%d", pills_left, MAX_PILLS);
    write_log_entry(log_entry);
}