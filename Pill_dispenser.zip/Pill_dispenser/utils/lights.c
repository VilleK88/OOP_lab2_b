#include "lights.h"
#include "eeprom.h"
#include "tools.h"

/*
 * Initialize all LEDs for PWM control.
 * - Each GPIO pin is configured for PWM mode.
 * - Each PWM slice is initialized only once (multiple channels may share a slice).
 * - All LEDs start with duty cycle 0.
 */
void init_leds() {
    // Track which PWM slices (0-7) have been initialized
    bool slice_ini[8] = {false};

    // Get default PWM configuration
    pwm_config config = pwm_get_default_config();
    // Set clock divider
    pwm_config_set_clkdiv_int(&config, CLK_DIV);
    // Set wrap (TOP)
    pwm_config_set_wrap(&config, TOP);

    for (int i = 0; i < LEDS_SIZE; i++) {
        // Get slice and channel for your GPIO pin
        const uint slice = pwm_gpio_to_slice_num(leds[i]);
        const uint chan = pwm_gpio_to_channel(leds[i]);

        // Disable PWM while configuring
        pwm_set_enabled(slice, false);

        // Initialize each slice once (sets divider and TOP for both A/B)
        if (!slice_ini[slice]) {
            pwm_init(slice, &config, false); // Do not start yet
            slice_ini[slice] = true;
        }

        // Set compare value (CC) to define duty cycle
        pwm_set_chan_level(slice, chan, 0);
        // Select PWM model for your pin
        gpio_set_function(leds[i], GPIO_FUNC_PWM);
        // Start PWM
        pwm_set_enabled(slice, true);
    }
}

/*
 * Validate stored LED states in EEPROM.
 * LED states are stored at addresses LED_R_ADDR → LED_L_ADDR (ascending).
 * Each state uses validated storage: state + ~state.
 */
bool check_if_led_states_are_valid() {
    for (int i = LED_R_ADDR; i <= LED_L_ADDR; i+=2) {
        led_state ls;
        read_state(i, &ls.state, &ls.not_state);
        if (!led_state_is_valid(&ls))
            return false;
    }
    return true;
}

/*
 * Read LED ON/OFF flag directly from EEPROM.
 * LIGHT_ON and LIGHT_OFF are single-byte values.
 */
bool light_on(const uint16_t addr) {
    if (read_byte(addr) == LIGHT_ON)
        return true;
    return false;
}

/*
 * Construct validated LED state (value + ~value).
 */
void set_led_state(led_state *ls, uint8_t const value) {
    ls->state = value;
    ls->not_state = ~value;
}

/*
 * Validate LED state pair stored in EEPROM.
 */
bool led_state_is_valid(const led_state *ls) {
    return ls->state == (uint8_t) ~ls->not_state;
}

/*
 * Initialize LED state values from EEPROM.
 * If EEPROM data is invalid, default all LEDs (L=OFF, M=ON, R=OFF).
 * LED_M is always turned ON during boot.
 */
void init_led_states() {
    if(!check_if_led_states_are_valid()) {
        init_led_state(LED_L, LED_L_ADDR, LIGHT_OFF);
        init_led_state(LED_M, LED_M_ADDR, LIGHT_ON);
        init_led_state(LED_R, LED_R_ADDR, LIGHT_OFF);
    }
    else
        init_led_state(LED_M, LED_M_ADDR, LIGHT_ON);
}

/*
 * Write LED state (validated) into EEPROM and update PWM brightness.
 */
void init_led_state(const uint led, const uint16_t addr, const uint8_t value) {
    led_state ls;
    set_led_state(&ls, value);
    write_state_bytes(addr, ls.state, ls.not_state);
    if (value == LIGHT_ON)
        set_brightness(led, BR_MID);
    else if (value == LIGHT_OFF)
        set_brightness(led, LIGHT_OFF);
}

/*
 * Toggle LED at given address.
 * Writes validated state to EEPROM and updates PWM brightness.
 */
void light_switch(const uint led, const uint16_t addr) {
    led_state ls;
    if (!light_on(addr)) {
        set_led_state(&ls, LIGHT_ON);
        write_state_bytes(addr, ls.state, ls.not_state);
        set_brightness(led, BR_MID);
    }
    else {
        set_led_state(&ls, LIGHT_OFF);
        write_state_bytes(addr, ls.state, ls.not_state);
        set_brightness(led, 0);
    }
}

/*
 * Update PWM duty cycle of LED.
 * - slice = PWM slice (0–7)
 * - chan  = PWM channel (A/B)
 */
void set_brightness(const uint led, const uint brightness) {
    const uint slice = pwm_gpio_to_slice_num(led);  // Get PWM slice for LED pin
    const uint chan  = pwm_gpio_to_channel(led); // Get PWM channel (A/B)
    pwm_set_chan_level(slice, chan, brightness); // Update duty cycle value
}

/*
 * Periodic LED blinking for status indication.
 * When max_ms time has elapsed, LED_M is toggled.
 */
void blinking_light(const uint32_t max_ms) {
    static uint32_t last_ms = 0;
    const uint32_t now_ms = get_ms();
    if (now_ms - last_ms >= max_ms) {
        last_ms = now_ms;
        light_switch(LED_M, LED_M_ADDR);
    }
}

/*
 * Clamp brightness to valid PWM range [0, MAX_BR].
 */
uint clamp(const int br) {
    // Limit brightness value to valid PWM range [0, MAX_BR]
    if (br < 0) return 0; // Lower bound
    if (br > MAX_BR) return MAX_BR; // Upper bound
    return br; // Within range
}