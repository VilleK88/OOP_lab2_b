#ifndef STEP_MOTOR_STATES_H
#define STEP_MOTOR_STATES_H

#include "../main.h"

// GPIO pins used to drive the four coils of the unipolar stepper motor.
// These pins must be driven in the correct sequence to rotate the motor.
#define IN1 2
#define IN2 3
#define IN3 6
#define IN4 13
#define INS_SIZE 4
// Array grouping all coil control pins for iteration.
static const uint coil_pins[] = {IN1, IN2, IN3, IN4}; // Stepper motor control pins

// Default number of half-steps per full revolution for a standard 28BYJ-48 stepper motor.
#define DEFAULT_STEPS_PER_REV 4096

#define CALIB_SAFE_MAX 12288 // Safety limit: 3 * 4096 steps
#define FALLING_EDGE_MAX 2 // Stop after 2 falling edges (1 interval) or reaching safety limit 4
#define POWER_OUTAGE_FALLING_EDGE_MAX 1

#define MOTOR_SLEEP_MS 2
#define REV_STEPS_SIZE 1

#define STEP_MOTOR_ON 1
#define STEP_MOTOR_OFF 0

#define CALIB_TRUE 1
#define CALIB_FALSE 0

/*
 * Structure for storing the stepper motor state in EEPROM.
 * `state` holds the value, `not_state` holds the bitwise complement for integrity checking.
 */
typedef struct step_motor_st {
    uint8_t state;
    uint8_t not_state;
} step_motor_st;

void init_coil_pins(); // Initialize motor coil output pins as outputs
void calibrate(); // Measure steps per revolution using the optical sensor
void motor_realignment_procedure(int direction); // Motor Realignment Procedure
void calib_after_power_outage();
void step_motor(int direction); // Perform one half-step of the stepper motor
void run_motor(int count); // Run the motor for N * (1/8) revolutions using the calibrated steps per revolution
void set_step_motor_state(step_motor_st *sms, uint8_t value);
void init_step_motor_st(bool valid);
void init_steps_per_rev();
bool motor_on();
int read_steps_per_rev();
int read_motor_count();
bool calibration_status();

#endif