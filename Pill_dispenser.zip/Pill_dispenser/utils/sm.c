#include "sm.h"
#include "lights.h"
#include "stepper_motor.h"
#include "sensor.h"
#include "pills.h"
#include "eeprom.h"
#include "tools.h"
#include "lora.h"

// Holds the current state of the state machine
static current_st current_state;
// Timing validator used across several states
static bool last_ms_valid = false;
static uint32_t last_ms = 0;

/*
 * Executes the handler of the current state.
 */
void run_sm() {
    states[current_state]();
}

/*
 * Performs state transition:
 * - Stores the new state in EEPROM (with redundancy)
 * - Updates the current_state variable
 */
void next_state(const current_st state) {
    write_current_st(state);
    current_state = state;
}

/*
 * Initial power-on state.
 * - Blinks LED to indicate inactive/waiting mode.
 */
void initial_st() {
    blinking_light(BLINKING_LIGHT_INITIAL_ST_MS);
}

/*
 * Calibration state:
 * - Turns off middle LED before calibration
 * - Runs the stepper motor calibration procedure
 */
void calib_st() {
    if (light_on(LED_M_ADDR))
        light_switch(LED_M, LED_M_ADDR);

    calibrate();
}

/*
 * Idle state:
 * - System waiting for user input or scheduled dispensing
 */
void idle_st() {

}

/*
 * Main dispensing state:
 * - Steps the motor one turn segment
 * - Checks if pill dropped immediately after the motor turn
 * - If pills are empty or motor exceeded safe count, trigger refill and reset
 */
void pill_dispensing_st() {
    const int motor_turn_count = read_motor_count();
    const int pills_count = read_pills_count();
    if (motor_turn_count >= 7 | pills_count <= 0) {
        write_state(MOTOR_COUNT_ADDR, 0);
        fill_the_pills(pills_count);
        if (!light_on(LED_M_ADDR))
            light_switch(LED_M, LED_M_ADDR);
        write_state(CALIB_STATUS_ADDR, CALIB_FALSE);
        state_change_info("Pill dispensing state -> Initial state");
        next_state(initial_state);
    }
    else {
        if (light_on(LED_M_ADDR))
            light_switch(LED_M, LED_M_ADDR);

        printf("Run motor count: %d.\r\n", motor_turn_count + 1);
        run_motor(1);
        write_state(MOTOR_COUNT_ADDR, motor_turn_count + 1);

        const bool pill_dropped = piezo_sensor_detect(); // Check whether the piezo sensor detected an impact
        if (pill_dropped) {
            last_ms_valid = false;
            if (light_on(LED_M_ADDR))
                light_switch(LED_M, LED_M_ADDR);
            process_pill_dispense(true);
            next_state(wait_turn_state);
        }
        else
            next_state(waiting_pill_to_drop_state);
    }
}

/*
 * Waiting window after motor turn:
 * - Gives the pill time to fall through the chute
 * - If no pill detected before timeout, go to pill_not_dropped_state
 */
void waiting_pill_to_drop_st() {
    const uint32_t now_ms = get_ms(); // Current timestamp in milliseconds since system startup
    validate_and_reset_ms(&last_ms_valid, &last_ms, &now_ms);
    bool pill_dropped = false;

    if (now_ms - last_ms >= WAITING_PILL_TO_DROP_MAX) {
        last_ms_valid = false;
        process_pill_dispense(false);
        next_state(pill_not_dropped_state); // If no pill was detected within the allowed time window, proceed
    }

    pill_dropped = piezo_sensor_detect(); // Check whether the piezo sensor detected an impact
    if (pill_dropped) {
        last_ms_valid = false;
        if (light_on(LED_M_ADDR))
            light_switch(LED_M, LED_M_ADDR);
        process_pill_dispense(true);
        next_state(wait_turn_state);
    }
}

/*
 * Error state when pill should have dropped but did not:
 * - Displays LED blinking
 * - Waits fixed duration before continuing cycle
 */
void pill_not_dropped_st() {
    const uint32_t now_ms = get_ms(); // Current timestamp in milliseconds since system startup
    validate_and_reset_ms(&last_ms_valid, &last_ms, &now_ms);

    if (now_ms - last_ms >= PILL_NOT_DROPPED_MAX) {
        last_ms_valid = false;
        next_state(wait_turn_state);
    }

    blinking_light(BLINKING_LIGHT_MS); // Toggle the indicator LED at a fixed interval
}

/*
 * Delay between dispensing cycles:
 * - Ensures proper mechanical reset timing
 */
void wait_turn_st() {
    const uint32_t now_ms = get_ms(); // Current timestamp in milliseconds since system startup
    validate_and_reset_ms(&last_ms_valid, &last_ms, &now_ms);

    if (now_ms - last_ms >= WAIT_TURN_MAX) {
        last_ms_valid = false;
        next_state(pill_dispensing_state); // If no pill was detected within the allowed time window, proceed
    }
}

/*
 * Recalibration state used after power outage while motor was running.
 */
void re_calib_st() {
    calib_after_power_outage();
}

/*
 * Returns true if the current state matches the supplied one.
 */
bool check_st(const current_st state) {
    if (state == current_state)
        return true;
    return false;
}

/*
 * Writes the current state to EEPROM (1 byte + its inverse).
 */
void write_current_st(const uint8_t value) {
    sm_state sms;
    set_sm_state(&sms, value);
    write_state_bytes(STATE_ADDR, sms.state, sms.not_state);
}

/*
 * Generates redundant state pair (value + bitwise-not).
 */
void set_sm_state(sm_state *sms, const uint8_t value) {
    sms->state = value;
    sms->not_state = ~value;
}

/*
 * Checks redundancy of stored state value.
 */
bool validate_current_st(const sm_state *sms) {
    return sms->state == (uint8_t) ~sms->not_state;
}

/*
 * Initializes state machine from EEPROM:
 * - If valid and within range, restore previous state
 * - Otherwise reset to initial_state
 */
void init_current_st() {
    sm_state sms;
    read_state(STATE_ADDR, &sms.state, &sms.not_state);
    if (validate_current_st(&sms) && sms.state <= 7) {
        write_current_st(sms.state);
        state_change_info(char_st(sms.state));
        next_state(sms.state);
    }
    else {
        write_current_st(0);
        state_change_info("Initial state");
        next_state(initial_state);
    }
}

/*
 * Converts state enum to human-readable text for logging.
 */
char *char_st(const current_st cst) {
    switch (cst) {
        case initial_state: return "Initial state";
        case calib_state: return "Calibration state";
        case idle_state: return "Idle state";
        case pill_dispensing_state: return "Pill dispensing state";
        case waiting_pill_to_drop_state: return "Waiting pill to drop state";
        case pill_not_dropped_state: return "Pill not dropped state";
        case wait_turn_state: return "Wait turn state";
        case re_calib_state: return "Recalibrating";
        default: return "Initial state";
    }
}

/*
 * Sends state transition information:
 * - Sends LoRa message
 * - Prints debug output
 */
void state_change_info(char *state_str) {
    send_msg(state_str);
    printf("%s.\r\n", state_str);
}

/*
 * Returns true if user button may be pressed in the current state.
 */
bool can_press() {
    if (current_state == initial_state | current_state == idle_state)
        return true;
    return false;
}