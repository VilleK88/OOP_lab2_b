#include "main.h"
#include "utils/eeprom.h"
#include "utils/stepper_motor.h"
#include "utils/sensor.h"
#include "utils/lora.h"
#include "utils/lights.h"
#include "utils/tools.h"

// Global event queue used by ISR (Interrupt Service Routine) and main loop
queue_t events;

int main() {

    // Initialize chosen serial port
    stdio_init_all();
    // Initialize buttons
    init_buttons();
    // Initialize LED pins
    init_leds();
    // Initialize UART
    init_uart();
    // Initialize I2C
    init_i2c();
    // Initialize stepper motor pins
    init_coil_pins();
    // Initialize piezo and optical sensor input (with internal pull-up)
    init_sensors();
    // Initialize EEPROM memory
    init_memory();
    // Check LoRa module connectivity and join network if available
    if (check_lora_comm())
        join_network();
    write_log_entry("Boot");
    // Restore or initialize stepper motor state machine
    init_starting_state();

    event_t event;
    while (true) {
        // Process pending events from the queue
        while (queue_try_remove(&events, &event) && can_press()) {

            if (event.type == EV_SW_R && event.data == 1) {
                if (check_st(idle_state) || check_st(initial_state))
                    print_log_entries();
            }

            if (event.type == EV_SW_M && event.data == 1) {
                if (calibration_status() && check_st(idle_state)) {
                    state_change_info("Idle state -> Pill dispensing state");
                    next_state(pill_dispensing_state);
                }
                else
                    printf("Calibrate first.\r\n");
            }

            if (event.type == EV_SW_L && event.data == 1) {
                if (check_st(initial_state) || check_st(idle_state))
                    next_state(calib_state);
            }
        }

        run_sm();
    }
}

//------------------------------------------------------------
// GPIO interrupt handler: handles button and piezo events.
// Implements edge detection + software debouncing.
//------------------------------------------------------------
void gpio_callback(uint const gpio, uint32_t const event_mask) {
    const uint32_t now = to_ms_since_boot(get_absolute_time());

    if (gpio == SW_R) {
        static uint32_t last_ms_r = 0; // Store last interrupt time
        // Detect button release (rising edge)
        if (event_mask & GPIO_IRQ_EDGE_RISE && now - last_ms_r >= DEBOUNCE_MS) {
            last_ms_r = now;
            const event_t event = { .type = EV_SW_R, .data = 0 };
            queue_try_add(&events, &event); // Add event to queue
        }
        // Detect button press (falling edge)
        if (event_mask & GPIO_IRQ_EDGE_FALL && now - last_ms_r >= DEBOUNCE_MS) {
            last_ms_r = now;
            const event_t event = { .type = EV_SW_R, .data = 1 };
            queue_try_add(&events, &event); // Add event to queue
        }
    }

    // Button press/release with debounce to ensure one physical press counts as one event
    if (gpio == SW_M) {
        static uint32_t last_ms_m = 0; // Store last interrupt time
        // Detect button release (rising edge)
        if (event_mask & GPIO_IRQ_EDGE_RISE && now - last_ms_m >= DEBOUNCE_MS) {
            last_ms_m = now;
            const event_t event = { .type = EV_SW_M, .data = 0 };
            queue_try_add(&events, &event); // Add event to queue
        }
        // Detect button press (falling edge)
        if (event_mask & GPIO_IRQ_EDGE_FALL && now - last_ms_m >= DEBOUNCE_MS){
            last_ms_m = now;
            const event_t event = { .type = EV_SW_M, .data = 1 };
            queue_try_add(&events, &event); // Add event to queue
        }
    }

    if (gpio == SW_L) {
        static uint32_t last_ms_l = 0; // Store last interrupt time
        // Detect button release (rising edge)
        if (event_mask & GPIO_IRQ_EDGE_RISE && now - last_ms_l >= DEBOUNCE_MS) {
            last_ms_l = now;
            const event_t event = { .type = EV_SW_L, .data = 0 };
            queue_try_add(&events, &event); // Add event to queue
        }
        // Detect button press (falling edge)
        if (event_mask & GPIO_IRQ_EDGE_FALL && now - last_ms_l >= DEBOUNCE_MS) {
            last_ms_l = now;
            const event_t event = { .type = EV_SW_L, .data = 1 };
            queue_try_add(&events, &event); // Add event to queue
        }
    }

    if (gpio == PIEZO_SENSOR) {
        static uint32_t last_ms_piezo = 0; // Store last interrupt time
        // Detect button release (rising edge)
        if (event_mask & GPIO_IRQ_EDGE_RISE && now - last_ms_piezo >= DEBOUNCE_MS) {
            last_ms_piezo = now;
            const event_t event = { .type = EV_PIEZO, .data = 0 };
            queue_try_add(&events, &event); // Add event to queue
        }
        // Detect button press (falling edge)
        if (event_mask & GPIO_IRQ_EDGE_FALL && now - last_ms_piezo >= DEBOUNCE_MS) {
            last_ms_piezo = now;
            const event_t event = { .type = EV_PIEZO, .data = 1 };
            queue_try_add(&events, &event); // Add event to queue
        }
    }
}

//------------------------------------------------------------
// Configure buttons as inputs and attach IRQ callbacks.
//------------------------------------------------------------
void init_buttons() {
    // Initialize event queue for Interrupt Service Routine (ISR)
    // 32 chosen as a safe buffer size: large enough to handle bursts of interrupts
    // without losing events, yet small enough to keep RAM usage minimal.
    queue_init(&events, sizeof(event_t), 32);

    for (int i = 0; i < BUTTONS_SIZE; i++) {
        gpio_init(buttons[i]); // Initialize GPIO pin
        gpio_set_dir(buttons[i], GPIO_IN); // Set as input
        gpio_pull_up(buttons[i]); // Enable internal pull-up resistor (button reads high = true when not pressed)
        // Configure button interrupt and callback
        gpio_set_irq_enabled_with_callback(buttons[i], GPIO_IRQ_EDGE_FALL |
            GPIO_IRQ_EDGE_RISE, true, &gpio_callback);
    }
}

//------------------------------------------------------------
// Startup logic deciding how to initialize the stepper motor
// state machine based on persisted EEPROM state validity.
//------------------------------------------------------------
void init_starting_state() {
    if (validate_state(STEP_MOTOR_ADDR) && validate_state(MOTOR_COUNT_ADDR) &&
        validate_state(CALIB_STATUS_ADDR) && validate_state16(STEPS_PER_REV_ADDR))
        init_step_motor_st(true);
    else
        init_step_motor_st(false);
    discard_events();
}